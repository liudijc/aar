namespace = '/test';
iphost='http://192.168.111.29:5000'
var socket = io.connect(iphost + namespace);

socket.on('connect', function() {//链接成功时 触发
    socket.emit('my_event', {data: 'I\'m connected!'});
    setInterval("zxt()","5000");



});


socket.on('my_response', function(msg) {
    $('#log').append('<br>' + $('<div/>').text('Received #' + msg.count + ': ' + msg.data).html());

});
socket.on('KHD-ZX',function(msg){


    if(msg.charAt(0)==="Z"){
        msg=msg.split("Z");
        let data=msg[1]*1
        tiaojieXT(2,data);

    }
    else if(msg.charAt(0)==="X"){

        msg=msg.split("X");
        let data=msg[1]*1
        tiaojieXT(1,data);
    }
    else if(msg.charAt(0)==="H"){

        msg=msg.split("H");
        let data=msg[1]*1
        tiaojieXT(3,data);
    }

    g_canvasBufferContext.fillStyle = "#FFFFFF";
    g_canvasBufferContext.fillRect(320,260,35,35);//背景的绘制
    g_canvasBufferContext.fillRect(280,260,35,35);//背景的绘制
    g_canvasBufferContext.fillRect(280-40,260,35,35);//背景的绘制



    g_canvasBufferContext.font = "20pt Microsoft JhengHei";
    g_canvasBufferContext.fillStyle = "#0000FF";
    g_canvasBufferContext.fillText(ZONGJUSHUx,320,280);
    g_canvasBufferContext.fillStyle = "#FF0000"; 　
    g_canvasBufferContext.fillText(ZONGJUSHUz,280,280);
    g_canvasBufferContext.fillStyle = "#006400"; 　
    g_canvasBufferContext.fillText(ZONGJUSHUh,280-40,280);





    //g_canvasBufferContext.closePath() //闭合路径

// *** *** ***
    // ZC: 从缓冲画布 往 网页画布<canvas/> 上画
    canvasContext.clearRect(0,0,2000,1000);

    canvasContext.drawImage(g_canvasBuffer, 0, 0, g_iWidth, g_iHeight, 0, 0, g_iWidth, g_iHeight);






});
socket.on('KHD-ZONGjine',function(msg){
    //alert(msg)


    var h2= document.getElementsByTagName("h2")[0];
    h2.innerHTML = "&nbsp&nbsp&nbsp&nbsp&nbsp "+msg;






    //tiaojie(10,Xyanse)
});
socket.on('KHD-zhuagtai',function(msg){
    //alert(msg)


    var h3= document.getElementsByTagName("h3")[0];
    h3.innerHTML = "&nbsp"+msg;






    //tiaojie(10,Xyanse)
});
socket.on('KHD-zongshuju',function(msg){
    //alert(msg)


    var h4= document.getElementsByTagName("h4")[0];
    h4.innerHTML = "&nbsp"+msg;






    //tiaojie(10,Xyanse)
});
socket.on('KHD-dtzhuangtai',function(msg){
    //alert(msg)


    var h5= document.getElementsByTagName("h5")[0];
    h5.innerHTML = "&nbsp"+msg;






    //tiaojie(10,Xyanse)
});
socket.on('KHD-zuotailiebiao',function(msg){
    //alert(msg)
    $("#zuotai").empty(); 

    strs=msg.split("\n"); //字符分割
    for (i=0;i<strs.length ;i++ )
    {
    //document.write(strs[i]+"<br/>"); //分割后的字符输出
    $("#zuotai").append("<option value='Value'>"+strs[i]+"</option>"); //添加一项option 
    }









    //tiaojie(10,Xyanse)
});
socket.on('KHD-dt',function(msg){
    //alert(msg)
    $("#ting").empty(); 

    strs=msg.split("\n"); //字符分割
    for (i=0;i<strs.length ;i++ )
    {
    //document.write(strs[i]+"<br/>"); //分割后的字符输出
    $("#ting").append("<option value='Value'>"+strs[i]+"</option>"); //添加一项option 
    }









    //tiaojie(10,Xyanse)
});


socket.on('KHD-buju',function(msg){
    //alert(msg)

    huoqubuju();






    //tiaojie(10,Xyanse)
});
var FSxinxi = function(a,b){
    //socket.emit('my_event', {data: 'I\'m connected!'});


    socket.emit(a,b);


}

var JSbuju=function(id,ZJE,DJLZ){


    var danjuLZ=DJLZ.split(",");
    huoqubuju();




    for (var i=0;i<danjuLZ.length;i++)

    {
        console.log(danjuLZ[i]);
        io.to(id).emit('KHD-ZX',danjuLZ[i]);

    }



    io.to(id).emit('KHD-ZONGjine',ZJE);


}
var zxt=function () {
  socket.emit('my_event', {data: 'I\'m connected!'});

}
